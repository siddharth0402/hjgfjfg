### Hotel-Management-System

The project is concerned with developing a flexible design for hotel management system that incorporates well-known design patterns such as Singleton, Factory and Strategy pattern. 
